-- Services
local Players = game:GetService("Players")

-- Configuration
local NEW_WALK_SPEED = 32 -- The desired faster walk speed
local GUI_NAME = "WalkSpeedToggleGUI" -- Name for the created ScreenGui
local BUTTON_NAME = "SpeedToggleBtn" -- Name for the created TextButton
local BUTTON_TEXT = "Toggle WalkSpeed" -- Text displayed on the button
local BUTTON_SIZE = UDim2.new(0, 150, 0, 50) -- Size of the button (width, height in pixels)
local BUTTON_POSITION = UDim2.new(0.5, -75, 0.8, 0) -- Position of the button (centered horizontally, near bottom)

-- Get the local player
local localPlayer = Players.LocalPlayer

-- Variables to manage toggle state and original speed
local isSpeedActive = false -- Tracks if the faster speed is currently active
local originalWalkSpeed = 16 -- Default Roblox walk speed, will be updated when character loads

-- Function to handle button clicks
local function onButtonClicked()
    -- Get the player's character
    local character = localPlayer.Character
    
    -- If the character doesn't exist yet, wait for it
    if not character or not character.Parent then
        character = localPlayer.CharacterAdded:Wait()
    end
    
    -- Get the Humanoid from the character
    local humanoid = character:WaitForChild("Humanoid")
    
    -- Store the original walk speed if it hasn't been set yet
    -- This ensures we capture the actual initial speed of the humanoid
    if originalWalkSpeed == 16 then -- Check against the initial default
        originalWalkSpeed = humanoid.WalkSpeed
    end

    -- Toggle the walk speed
    if isSpeedActive then
        -- If faster speed is active, revert to original speed
        humanoid.WalkSpeed = originalWalkSpeed
        isSpeedActive = false
    else
        -- If original speed is active, set to the new faster speed
        humanoid.WalkSpeed = NEW_WALK_SPEED
        isSpeedActive = true
    end
end

-- Function to create the GUI
local function createGUI()
    -- Create the ScreenGui
    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = GUI_NAME
    screenGui.ResetOnSpawn = false -- Keep the GUI visible across character respawns

    -- Create the TextButton
    local button = Instance.new("TextButton")
    button.Name = BUTTON_NAME
    button.Size = BUTTON_SIZE
    button.Position = BUTTON_POSITION
    button.AnchorPoint = Vector2.new(0.5, 0.5) -- Anchor point for centering
    button.Text = BUTTON_TEXT
    button.BackgroundColor3 = Color3.fromRGB(85, 170, 255) -- Blue color
    button.TextColor3 = Color3.fromRGB(255, 255, 255) -- White text
    button.Font = Enum.Font.SourceSansBold
    button.TextScaled = true -- Scale text to fit button size
    button.BorderSizePixel = 0 -- No border

    -- Parent the button to the ScreenGui
    button.Parent = screenGui

    -- Connect the button's click event to the function
    button.MouseButton1Click:Connect(onButtonClicked)

    -- Parent the ScreenGui to the player's PlayerGui
    screenGui.Parent = localPlayer:WaitForChild("PlayerGui")
end

-- Call the function to create the GUI when the script runs
createGUI()